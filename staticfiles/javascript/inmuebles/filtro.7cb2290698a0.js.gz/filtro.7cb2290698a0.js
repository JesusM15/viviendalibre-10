var btn_search = document.getElementById('btn-search');
var btn_filtrar = document.getElementById('btn-filtrar');
